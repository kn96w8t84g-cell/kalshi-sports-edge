# Kalshi Sports Edge V3

A personal, research-oriented dashboard for comparing independent sports probability estimates with Kalshi market prices for **tennis, MLB, and college football**.

## What it does
- Pulls open Kalshi markets from the public market-data API.
- Classifies likely tennis / MLB / CFB markets.
- Pulls sports data from public/optional sources.
- Builds conservative baseline probabilities using ratings, recent form, matchup features, and uncertainty penalties.
- Compares model probability to Kalshi price and labels **STRONG / WATCH / PASS**.
- Records predictions so you can measure calibration and realized performance rather than cherry-picking wins.
- Never places trades and never asks for your Kalshi credentials.

## Important
This is decision-support software, not a guarantee or financial advice. Sports outcomes are uncertain. A high model probability can still lose. The program intentionally produces PASS when data quality is poor or the estimated edge is too small.

## Data sources
- Kalshi public market-data API: current markets/order books.
- MLB Stats API: schedules and team/player data.
- CollegeFootballData: optional API key for CFB statistics.
- Jeff Sackmann tennis datasets: historical ATP/WTA match data.

Kalshi public market-data endpoints are documented here:
https://docs.kalshi.com/getting_started/quick_start_market_data

MLB Stats API wrapper/documentation:
https://github.com/toddrob99/MLB-StatsAPI/wiki/Endpoints

CollegeFootballData:
https://collegefootballdata.com/

## Run
1. Install Python 3.11+.
2. Create a virtual environment.
3. `pip install -r requirements.txt`
4. Copy `.env.example` to `.env` and optionally add a CFBD key.
5. Run: `streamlit run app.py`

## Tabs
- **Today's Edge Board**: ranked opportunities.
- **Markets**: raw Kalshi markets and prices.
- **Model Detail**: feature breakdown for a selected game.
- **Tracker**: prediction history, win rate, Brier score, ROI-style paper results, calibration.
- **Settings**: thresholds and data-source status.

## Safety design
- No auto-trading.
- No account credentials.
- No forced picks.
- No fake confidence scores when inputs are missing.
- Every pick has a data-quality score and an explanation.

## Recommended workflow
Use the system in paper mode first. Collect at least a few hundred predictions before deciding whether any sport/league/model combination has a repeatable edge.
